package com.infinite.VizagMvc.Service;

import java.util.List;

import com.infinite.VizagMvc.Model.Municipal;

public interface IMuncipalService {

	public List<Municipal> getAllComplains();

	public Municipal getMunicipal(int id);

	public Municipal addMunicipal(Municipal municipal);

	public void updateMunicipal(Municipal municipal);

	public void deleteMunicipal(int id);
}
