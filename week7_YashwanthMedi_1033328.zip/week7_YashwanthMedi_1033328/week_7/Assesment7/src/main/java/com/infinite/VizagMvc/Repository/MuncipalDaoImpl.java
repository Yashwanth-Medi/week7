package com.infinite.VizagMvc.Repository;

import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infinite.VizagMvc.Model.Municipal;

@Repository
public class MuncipalDaoImpl implements IMuncipalDao {
//implementing imuncipal dao from interface
	@Autowired
	private SessionFactory sessionf;

	public void setSfactory(SessionFactory sfactory) {//session creation
		this.sessionf = sessionf;
	}

	@Override
	public List<Municipal> getAllComplains() {// 
		// TODO Auto-generated method stub
		Session ses = this.sessionf.getCurrentSession();
		List<Municipal> lm = ses.createQuery("from Municipal").list();
		return lm;

	}

	@Override
	public Municipal getMunicipal(int id) {
		// TODO Auto-generated method stub
		Session session = this.sessionf.getCurrentSession();
		Municipal municipal = (Municipal) session.get(Municipal.class, id);
		return municipal;

	}

	@Override
	public Municipal addMunicipal(Municipal municipal) {
		// TODO Auto-generated method stub
		Session session = this.sessionf.getCurrentSession();
		session.save(municipal);
		return municipal;

	}

	@Override
	public void updateMunicipal(Municipal municipal) {
		// TODO Auto-generated method stub
		Session session = this.sessionf.getCurrentSession();
		Hibernate.initialize(municipal);
		session.update(municipal);
	}

	@Override
	public void deleteMunicipal(int id) {
		// TODO Auto-generated method stub
		Session session = this.sessionf.getCurrentSession();
		Municipal mc = (Municipal) session.load(Municipal.class, new Integer(id));
		if (null != mc) {
			session.delete(mc);
		}
	}

}
