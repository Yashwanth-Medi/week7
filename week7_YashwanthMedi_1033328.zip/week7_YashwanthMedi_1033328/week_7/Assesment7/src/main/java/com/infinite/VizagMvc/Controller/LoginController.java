package com.infinite.VizagMvc.Controller;

import org.springframework.stereotype.Controller;

@Controller
public class LoginController {

}
