package com.infinite.VizagMvc.Service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinite.VizagMvc.Model.Municipal;
import com.infinite.VizagMvc.Repository.MuncipalDaoImpl;

@Service
public class MuncipalServiceImpl implements IMuncipalService {

	@Autowired
	MuncipalDaoImpl mdi;

	@Transactional
	public List<Municipal> getAllComplains() {
		// TODO Auto-generated method stub

		return mdi.getAllComplains();
	}

	@Transactional
	public Municipal getMunicipal(int id) {
		// TODO Auto-generated method stub
		return mdi.getMunicipal(id);
	}

	@Transactional
	public Municipal addMunicipal(Municipal municipal) {
		// TODO Auto-generated method stub
		return mdi.addMunicipal(municipal);
	}

	@Transactional
	public void updateMunicipal(Municipal municipal) {
		// TODO Auto-generated method stub
		mdi.updateMunicipal(municipal);
	}

	@Transactional
	public void deleteMunicipal(int id) {
		// TODO Auto-generated method stub
		mdi.deleteMunicipal(id);
	}

}
